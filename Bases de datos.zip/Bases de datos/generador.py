import os
import random

# Crear la carpeta donde se guardarán los 200 archivos
directorio = "corpus_documentos"
if not os.path.exists(directorio):
    os.makedirs(directorio)

# Definimos temáticas con el vocabulario de tu profesor: coche, auto, perro, can
tematicas = {
    "vehiculos": [
        "El coche es muy rápido y seguro.", "Compré un auto nuevo ayer.",
        "El motor hace mucho ruido.", "Ese coche rojo es de mi hermano.",
        "Me gusta conducir mi auto.", "El mecánico reparó el motor del coche.",
        "El auto se quedó sin gasolina."
    ],
    "animales": [
        "El perro ladra todas las mañanas.", "Mi mascota es el can que adopté.",
        "El can es el mejor amigo del hombre.", "Ese perro tiene un pelaje brillante.",
        "Llevé a mi perro al veterinario.", "El can jugaba alegremente."
    ],
    "tecnologia": [
        "La base de datos es eficiente.", "El algoritmo procesa texto.",
        "El servidor en la nube está activo.", "Python es un lenguaje de programación.",
        "La recuperación de información mejora con LSI."
    ]
}

print(f"Generando 200 documentos en la carpeta '{directorio}'...")

for i in range(1, 201):
    tema_principal = random.choice(list(tematicas.keys()))
    frases_elegidas = random.sample(tematicas[tema_principal], random.randint(2, 3))
    contenido = " ".join(frases_elegidas)
    
    nombre_archivo = f"doc_{i:03d}.txt"
    ruta_completa = os.path.join(directorio, nombre_archivo)
    
    with open(ruta_completa, "w", encoding="utf-8") as f:
        f.write(contenido)

print("¡Éxito! Los 200 archivos se han creado.")