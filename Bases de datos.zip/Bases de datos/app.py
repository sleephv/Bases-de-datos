from flask import Flask, render_template, request, jsonify
import os
from sklearn.feature_extraction.text import CountVectorizer, TfidfVectorizer
from sklearn.decomposition import TruncatedSVD
from sklearn.metrics.pairwise import cosine_similarity

app = Flask(__name__)

# Cargar documentos
documentos = []
nombres = []
for f in sorted(os.listdir("corpus_documentos")):
    with open(f"corpus_documentos/{f}", "r", encoding="utf-8") as file:
        documentos.append(file.read())
        nombres.append(f)

# Inicializar vectores
cv = CountVectorizer(lowercase=True)
tfidf_vec = TfidfVectorizer(lowercase=True)

matriz_count = cv.fit_transform(documentos)
matriz_tfidf = tfidf_vec.fit_transform(documentos)

# LSI
svd = TruncatedSVD(n_components=10)
matriz_lsi = svd.fit_transform(matriz_count)

def jaccard_similarity(query, doc):
    q_set = set(query.lower().split())
    d_set = set(doc.lower().split())
    intersection = len(q_set.intersection(d_set))
    union = len(q_set.union(d_set))
    return intersection / union if union != 0 else 0

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/buscar', methods=['POST'])
def buscar():
    data = request.json
    query = data['query']
    metodo = data['metodo']
    
    resultados = []
    
    if metodo == "lsi":
        q_vec = cv.transform([query])
        q_lsi = svd.transform(q_vec)
        sims = cosine_similarity(q_lsi, matriz_lsi)[0]
    elif metodo == "tfidf":
        q_vec = tfidf_vec.transform([query])
        sims = cosine_similarity(q_vec, matriz_tfidf)[0]
    elif metodo == "tradicional":
        q_vec = cv.transform([query])
        sims = cosine_similarity(q_vec, matriz_count)[0]
    elif metodo == "jaccard":
        sims = [jaccard_similarity(query, d) for d in documentos]
    
    # Formatear resultados
    indices = sorted(range(len(sims)), key=lambda i: sims[i], reverse=True)[:5]
    for i in indices:
        if sims[i] > 0.0:
            resultados.append({"doc": nombres[i], "score": round(sims[i]*100, 2), "text": documentos[i]})
            
    return jsonify(resultados)

if __name__ == '__main__':
    app.run(debug=True)